<?php
session_start();
require 'config.php';
include_once('configi.php');

if(empty($_SESSION['id_user'])) {
	$id = $_SESSION['id_user'];

	header("Location:login.php");
}


if(isset($_POST['update']))
{
	echo $asx;
        $status =['status'];
        $asx = $_POST['asx'];
	$query = mysqli_query($conexao, "UPDATE pedidos SET status= 'fechado' WHERE mesa ='$asx'");
	
	if($query){
		echo ' Atualização realizada com sucesso';
	}
	else{
		echo ' error';
	}
	

	
	
	
	

	
}


?>
<head>
        <meta charset="utf-8">
       <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
            <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary">FORZAKE</h2>
        </a>

                <a href="index/index.php" class="nav-item nav-link active">Inicio</a>
                <a href="comandas.php" class="nav-item nav-link">Comandas</a>
                <a href="sair.php" class="nav-item nav-link">Sair</a>
                
        
    </nav>
    </body>
<form method="GET">
    <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="Produtos"</h6>
                            <table class="table">
			<thead>
				<tr>
					<th>Produto</th>
					<th>Valor</th>
				</tr>
			</thead>
			<tbody>	

</form>
<form action="fecharconta.php"method="POST">
    
    <input type="hidden" value="fechado" id="status" name="status">
          <input type="hidden" value="<?php echo $haa = $_GET['h']; ?>"  id="asx" name="asx">
      <button class="form-control form-control-name" id='update' name='update' value="update" type="upadate"  class="login100-form-btn"> Finalizar</button>

    
</form>


 <p class="text-center mb-0"><a href="garcom.php">COMANDA MESA : <?php echo $h = $_GET['h']; ?></a></p>
 


	<?php
	
	            if(isset($_GET['h'])) {
	
	$h = $_GET['h'];

	

	
	$sql = "SELECT *  FROM pedidos WHERE mesa= :h and status = 'aberto' ";
	$sql = $pdo->prepare($sql);
	$sql->bindValue(":h", $h);
	$sql->execute();
	
		

	if($sql->rowCount() > 0){
	   foreach ($sql->fetchAll() as $produto):
		  ?>
				 			<tr>
				 				<td><?php echo $produto['pedidos']; ?></td>
				 				<td name="soma"><?php echo $produto['valorvenda']; ?></td>
				 				
				 			    </tr>
				 			    
				 		<?php endforeach;}}?>
				 		
				 		
			<?php
	
	            if(isset($_GET['h'])) {
	
	$h2 = $_GET['h'];

	

	
	$sql2 = "SELECT ROUND(sum(valorvenda),2)  FROM pedidos WHERE mesa= :h and status = 'aberto'  ";
	$sql2 = $pdo->prepare($sql2);
	$sql2->bindValue(":h", $h2);
	$sql2->execute();
	
		

	if($sql2->rowCount() > 0){
	   foreach ($sql2->fetchAll() as $produto2):
		  ?>
				 			<tr>
				 				
				 				<h3 name="soma">Valor Total <?php echo $produto2['ROUND(sum(valorvenda),2)']; ?>  R$</h3>
				 					
				 			    </tr>
				 			    
				 		<?php endforeach;}}?>
				 		
				 		<?php
		?>
		 	