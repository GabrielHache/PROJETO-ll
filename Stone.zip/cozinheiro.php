<?php
session_start();
require 'config.php';
if(isset($_SESSION['id_user']) && !empty($_SESSION['id_user']) ){
	 "SEU ID: ".$_SESSION['id_user'];}
		else {
			header("Location: login.php");
		}
header("Refresh: 5; url = cozinheiro.php");
?>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="bootstrap.min.css"/>
	<script type="text/javascript" src="jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap.min.js"></script>
</head>
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary">FORZAKE</h2>
        </a>

     
                <a href="index/index.php" class="nav-item nav-link active">Inicio</a>
                <a href="garcom.php" class="nav-item nav-link">Produtos</a>
               
                
    </nav>

		<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="Produtos"</h6>
                            <table class="table">
		<thead>
			<tr>
			    <th>ID#</th>
				<th>Pedidos</th>
				<th>Mesa</th>
				<th>Hora</th>
				<th>OBS</th>
				<th>Finalizar</th>
			</tr>
		</thead>
		<tbody>
			<?php
		 	$sql = "SELECT * FROM pedidos where status ='aberto' and categoria = 'cozinha' and cozinhastatus='false' order by id_pedidos asc";
		 	$sql = $pdo->query($sql);
		 	if ($sql->rowCount()>0){
		 		foreach ($sql->fetchAll() as $pedido) {
		 			echo '<tr>';
		 			echo '<td>'.$pedido['id_pedidos'].'</td>';
		 			echo '<td>'.$pedido['pedidos'].'</td>';
		 			echo '<td>'.$pedido['mesa'].'</td>';
		 			echo '<td>'.$pedido['hora'].'</td>';
		 			echo '<td><b>'.$pedido['obs'].'</b></td>';
		 			echo"<td> <a onclick='clicks()' href='index/Relatorios/rel/cozinhafechamento.php?id=$pedido[id_pedidos]'><p> Finalizar Pedido</p></a></td>";
		 			
		 	    
		 			echo '</tr>';
		 		}
		 	}

			?>
		</tbody>
		
		<script>
		    function clicks() {
		        alert('Para finalizar o pedido deve sempre gravar seu número de ID pois sera necessario')
		    }
		</script>
	</table>
	
	<a href="sair.php">Sair</a><br/>
</div>

