<?php
session_start();
require 'config.php';

if(isset($_SESSION['id_user']) && !empty($_SESSION['id_user']) ){

	}
	else {
		header("Location: login.php");
	}
?>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="bootstrap.min.css"/>
	<script type="text/javascript" src="jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap.min.js"></script>
	    <meta charset="utf-8">
    
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary">FORZAKE</h2>
        </a>

     
                <a href="index/index.php" class="nav-item nav-link active">Inicio</a>
                <a href="garcom.php" class="nav-item nav-link">Produtos</a>
               
                
    
    </nav>

		<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="Produtos"</h6>
                            <table class="table">
			<thead>
				<tr>
					<th>Mesas em aberto</th>
									
				</tr>
			</thead>
			<tbody>	
				<?php

					$sql = "SELECT DISTINCT mesa FROM pedidos WHERE status='aberto'";
					$sql = $pdo->query($sql);
					 if ($sql->rowCount()>0){
				 		foreach ($sql->fetchAll() as $produto):
				 			?>
				 			<tr>
				 				<td><?php echo $produto['mesa']; ?></td>

				 			  <td><a href="fecharconta.php?h=<?php echo $produto['mesa'];?>">Fechar conta</a></td>
				 			</tr>
				 		<?php endforeach; }?>
			</tbody>
		</table><br/><br/><br/>
</div>