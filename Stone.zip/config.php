<?php
try{
	$pdo = new PDO("mysql:dbname=u338827785_stone;host=localhost;","u338827785_stone","326974@ghP");

} catch (PDOExcetion $e){
	echo "ERRO: ".$e->getMessage();
	exit;
}
?>