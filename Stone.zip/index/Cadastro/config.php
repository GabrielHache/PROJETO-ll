<?php
 
 $dbHost= 'localhost';
 $dbUsername = 'u338827785_stone';
 $dbPassword = '326974@ghP';
 $dbName = 'u338827785_stone';
 

 $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);


 if ($conexao->connect_errno)
 {
     echo "erro";

 }







?>