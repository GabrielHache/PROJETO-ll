<?php
 if(isset($_POST['submit']))
 {
   //  print_r($_POST['nome']);
    // print_r($_POST['email']);
    // print_r($_POST['categoria']);
 
include_once('config.php');

$nome= $_POST['nome'];
$CPF= $_POST['CPF'];
$Bairro= $_POST['Bairro'];
$Fone= $_POST['Fone'];
$data=$_POST['data'];
$demanda=$_POST['demanda'];
$contagem=$_POST['contagem'];



   $result = mysqli_query($conexao, "INSERT INTO clientes(nome,cpf,bairro,fone) VALUES('$nome','$CPF','$Bairro','$Fone')");
   
}

?>





<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> FORZAKE SISTEM</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="freehtml5.co" />



	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<a href="../index.php">
		<input  type="button" value="Voltar">
		</a>
	<div class="fh5co-loader"></div>
	
	<div id="page">	
		<div id="fh5co-consult">
			<div class="video fh5co-video" style="background-image: url(images/imagem\ stone/stonelogo.jpg);">
				<div class="overlay"></div>
			</div>
			<div class="choose animate-box">
				<h2>Cadastro de cliente</h2>
				<form action="Cadastro cliente.php"   method='POST'>
					<div class="row form-group">
						<div class="col-md-6">
							<label for="nome">Nome</label>
							<input type="text" id="nome" name="nome" class="form-control" placeholder="Nome">
						</div>
						<br>

					</div>
					<div class="row form-group">
						<div class="col-md-6">
							<label for="nome_Valor">CPF / CNPJ</label>
							<input type="text" id="CPF" name="CPF" class="form-control" placeholder="CPF / CNPJ">
						</div>
					</div>
					<div class="row form-group">
						<div class="col-md-6">
							<label for="nome_Valor">Bairro</label>
							<input type="text" id="Bairro" name="Bairro" class="form-control" placeholder="Bairro">
						</div>
					</div>
					<div class="row form-group">
						<div class="col-md-6">
							<label for="nome_Valor">Fone</label>
							<input type="fone" id="Fone" name="Fone" class="form-control" placeholder="(66) 9 9999-9999">
						</div>
					</div>
					
					<div class="form-group">
						<input id="submit" name="submit" type="submit" value="Cadastro" class="btn btn-primary">
					</div>
	
				</form>	
			</div>
		</div>
	

							
							
					    </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	

	</header>


	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up22"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Easy PieChart -->
	<script src="js/jquery.easypiechart.min.js"></script>
	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>
	
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

