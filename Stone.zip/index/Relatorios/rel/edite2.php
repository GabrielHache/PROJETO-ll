
<?php

    include_once('config.php');
    
    if(isset($_POST['update']))
    {
        
        $id = $_POST['id'];
        $nome= $_POST['nome'];
        $cpf=$_POST['cpf'];
        $bairro=$_POST['bairro'];
        $fone=$_POST['fone'];
        $query = mysqli_query($conexao, "UPDATE clientes SET nome='$nome',cpf='$cpf', bairro='$bairro', fone='$fone' WHERE id='$id'");
        
        if($query){
            echo ' Atualização realizada com sucesso';
        }
        else{
            echo ' error';
        }
        
        header('Location:Clientes.php');
        
        
        
        
    
        
    }
  
        
   ?>


<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Registro de atendimento</title>
      <meta name="keywords" content="">
      <meta name="description" content="Registro de Atendimento">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/cadastroo.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
        
           
            
         </div>
         <div class="booking_ocline">
            <div class="container">
               <div class="row">
                  <div class="col-md-5">
                     <div class="book_room">
                        <h1>Editar produto</h1>

  
                        <form action="edite2.php"  method='POST'>
                           <div class="row">
                              <div class="col-md-12">
                                 <br>
                                  
                                  <br>
                                  <br>
                                  <label from='Nome'>Nome</label>
                                  <input class="form-control form-control-name" class="input100" type="text" id='nome'  name="nome" required placeholder='Digete o novo nome'>
                                  <br>
                                  
                                  <label from='raz'>CPF/CNPJ</label>
                                     <input class="form-control form-control-name" class="input100" type="text" id='cpf'name='cpf' placeholder='Digete o novo cpf'>
                                  
                                  
                                  <br>
                                  <br>
                                  <label from='gerente'>Bairro</label>
                                  <input class="form-control form-control-name" class="input100" type="text" id='bairro' name='bairro' placeholder='Digite o novo bairro'>
                                  <br>
                                  <br>
                                  <label from='gerente'>Fone</label>
                                  <input class="form-control form-control-name" class="input100" type="text" id='fone' name='fone' placeholder='Digite o novo fone'>
                                  <br>
                                  <br>
                                  <input name="id" required placeholder='ID' id="id">
                                  <br>
                                  <br>
                                  
                                  
                                  
                              </div>
                				
                              </div>
                              <button class="form-control form-control-name" id='update' name='update' value="update" type="upadate"  class="login100-form-btn"> Enviar</button>
                              </div>
                           
                                              </div>
                                             
                                           </div>
                         </form>
                         
                        
                                     </div>
                                  </div>
                               </div>
                            </div>
                         </div>
      </section>
      <!-- end banner -->
      <!-- about -->
      
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>