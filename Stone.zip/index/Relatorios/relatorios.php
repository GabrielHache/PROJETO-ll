<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>
    FORZAKE SISTEM
  </title>

  <!-- range selctor slider style -->


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/css/ion.rangeSlider.min.css" />
  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  
  <section class="service_section layout_padding" id="service">
    <div class="container">
      <div class="heading_container">
        <h2>
         Relatórios
        </h2>
      
      </div>
    </div>
    <div class="container">
      <div class="box container-bg">
        <div class="detail-box">
          <div class="img-box">
            <img src="images/icone cliente.png" alt="" class="img1">
            <img src="images/icone cliente.png" alt="" class="img2">
          </div>
          <div class="text-box">
            <h6>
              Relatório de Clientes
            </h6>
          
          </div>
        </div>
        <div class="detail-box">
          <div class="img-box">
              <a href="rel/produtos.php">
            <img src="images/icone produto.png" class="img1">
            <img src="images/icone produto.png" alt="" class="img2">
          </div>
          <div class="text-box">
            <h6>
              Relatório de Produtos
            </h6>
          </a>
          </div>
        </div>
        <div class="detail-box">
          <div class="img-box">
            <img src="images/indicadores.png" alt="" class="img1">
            <img src="images/indicadores.png" alt="" class="img2">
          </div>
          <div class="text-box">
            <h6>
              RCTM001
            </h6>
            <p>
              Relatório de produtos mais vendidos.
            </p>
          </div>
        </div>
  
      </div>
    </div>
  </section>

  <!-- end service section -->

  <!-- blog section -->

  



  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>

  <!-- range selector slider script -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/js/ion.rangeSlider.min.js"></script>

  <script>
    $(".js-range-slider").ionRangeSlider({
      skin: "round",
      type: "double",
      min: 200,
      max: 10000,
      from: 200,
      to: 500,
      grid: true
    });
  </script>

</body>

</html>