
<?php



include_once('config.php');


$dataifo=$_POST['datainfo'];
$sql = "SELECT * FROM pedidos ORDER BY id DESC";
$result = $conexao->query($sql);




?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homologações</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="plugins/fontawesome/css/all.min.css">
  <!-- Animation -->
  <link rel="stylesheet" href="plugins/animate-css/animate.css">
  <!-- slick Carousel -->
  <link rel="stylesheet" href="plugins/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick/slick-theme.css">
  <!-- Colorbox -->
  <link rel="stylesheet" href="plugins/colorbox/colorbox.css">
  <!-- Template styles-->
  <link rel="stylesheet" href="css/tabela.css">
  
  
  
  
   
 
  <br>
  <br>

</head>
<body>
    <input name="datainfo" id="datainfo" type="Data"> <br> <button>Refesh</button>
    
    <div  class="container">
    <table class="table">
        <thead>
          <tr>
            
 		<th scope="col">ID</th>
         <th scope="col">Produto</th>
         <th scope="col">Valor de Venda</th>
         
          <th scope="col">...</th>
          <th scope="col">Notas</th>
          </tr>
        </thead>
        <tbody>
            <?php
                while($user_data = mysqli_fetch_assoc($result))
                {
                    echo"<tr>";
                    echo"<td>".$user_data['pedidos']."</td>";
                    echo"<td>".$user_data['mesa']."</td>";
                    echo"<td>".$user_data['valorvenda']."</td>";
                    echo"<td>".$user_data['hora']."</td>";
                   
                    echo"<td> <a href='edite.php?id=$user_data[id]'><p>Atualizar</p></a></td>";
                    echo"<td ><a href='nota.php?id=$user_data[id]''>".$user_data['nota']."..</a></td>";
                    echo"<td> <a href='relatorio.php?id=$user_data[id]'><p>Historico</p></a></td>";
                    
                    
                  
                }
        
        ?>
        </tbody>
      </table>
      </div>
    
</body>

</html>