<?php
session_start();
require 'config.php';

if(isset($_SESSION['id_user']) && !empty($_SESSION['id_user']) ){
	
	}
	else {
		header("Location:index.php");
	}
	if(isset($_POST['submit']))
 {
 
 

include_once('configi.php');
    $pedidos= $_POST['pedidos'];
    $valor= $_POST['valor'];
    $mesa= $_POST['mesa'];
    $obs=$_POST['obs'];
    $categoria=$_POST['categoria'];
    $valorcusto=$_POST['valorcusto'];
    $cozinhastatus=$_POST['cozinhastatus'];
    $status=$_POST['status'];
   




     $result = mysqli_query($conexao, "INSERT INTO pedidos(pedidos,valorvenda,mesa,obs,categoria,valorcusto,cozinhastatus,status) VALUES('$pedidos','$valor','$mesa','$obs','$categoria','$valorcusto','$cozinhastatus','$status')");
	 
	 }
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>FORZAKE</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Spinner End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
         <a href="#" class="sidebar-toggler flex-shrink-0">
            <h2 class="m-0 text-primary">FORZAKE</h2>
        </a>
        
           <a href="index/index.php" class="nav-item nav-link active">Inicio</a>
                <a href="comandas.php" class="nav-item nav-link">Comandas</a>
                <a href="sair.php" class="nav-item nav-link">Sair</a>
            
    </nav>


    <div class="col-sm-12 col-xl-6">
        <div class="bg-secondary rounded h-100 p-4">
            <div id="personalizado" name="personalizado">
<h1>Pedidos Personalizado</h1>
           


<form action="pedidospersonalizados.php" method="POST">

                    <input type='text' name="pedidos" id="pedidos" placeholder="Digite o nome">
                    <br><br>
                    <input type='money' name="valor" id="valor" placeholder="Digite o valor">
                    <br><br>
                    <input name="mesa" id="mesa" placeholder="Número da mesa">
                    <br><br>
                    <br><br>
                    <input type="text" name="obs" id="obs" placeholder="Observação">
                    <br><br>
                    
                    <input type="hidden" name="categoria" id="categoria" value="Cozinha">
                    
                    <input type="hidden" name="valorcusto" id="valorcusto" value="0">
                   
                    <input type="hidden" name="cozinhastatus" id="cozinhastatus" value="false">
                    <input type="hidden" name="status" id="status" value="Aberto">
                    <input type="submit" id='submit' name="submit" value="Enviar" class="btn btn-primary">

                </form>

            </div>
        </div>
    </div>
</div>

</body>

</html>                
