<?php
session_start();
require 'config.php';

if(isset($_SESSION['id_user']) && !empty($_SESSION['id_user']) ){
	
	}
	else {
		header("Location:index.php");
	}
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>FORZAKE</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Spinner End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
         <a href="#" class="sidebar-toggler flex-shrink-0">
            <h2 class="m-0 text-primary">FORZAKE</h2>
        </a>
        
           <a href="index/index.php" class="nav-item nav-link active">Inicio</a>
                <a href="comandas.php" class="nav-item nav-link">Comandas</a>

            
    </nav>


		<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="Produtos"</h6>
                            <table class="table">
			<thead>
				<tr>
					<th>Produto</th>
					<th>Valor</th>
						
					<th type="hidden ">Encaminhar</th>	
				</tr>
			</thead>
			<tbody>	
				<?php

					$sql = "SELECT * FROM produtos order by produto asc";
					$sql = $pdo->query($sql);
					 if ($sql->rowCount()>0){
				 		foreach ($sql->fetchAll() as $produto):
				 			?>
				 			<tr>
				 				<td><?php echo $produto['produto']; ?></td>
				 				<td><?php echo $produto['vendaValor']; ?></td>
				 				
				 				<td><a href="add-pedido.php?h=<?php echo $produto['id'];?>">Encaminhar</a></td>
				 				<td type="hidden "><?php echo $categoria['categoria']; ?></td>
				 				
				 			</tr>
				 		<?php endforeach; }?>
			</tbody>
		</table><br/><br/><br/>
		<button><a href="pedidospersonalizados.php">`Pedidos Personalizados</a></button>
</div>


                       